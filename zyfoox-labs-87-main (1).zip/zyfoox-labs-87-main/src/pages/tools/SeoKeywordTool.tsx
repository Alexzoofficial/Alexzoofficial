
import { useState } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import ToolInterface from "@/components/tools/ToolInterface";
import { Search } from "lucide-react";

export default function SeoKeywordTool() {
  // Function to analyze keywords
  const analyzeKeywords = async (formData: Record<string, string>) => {
    try {
      const { keywords, industry, language } = formData;
      
      // Simulated API response (in a real app, this would come from an API)
      const keywordArray = keywords.split(',').map(k => k.trim()).filter(k => k.length > 0);
      
      let result = `# SEO Keyword Analysis\n\n`;
      result += `Industry: ${industry}\n`;
      result += `Language: ${language}\n\n`;
      
      result += `## Keyword Insights\n\n`;
      
      // For each keyword, generate a simulated analysis
      keywordArray.forEach(keyword => {
        const wordCount = keyword.split(' ').length;
        const difficulty = Math.floor(Math.random() * 100);
        const volume = Math.floor(Math.random() * 10000);
        const competition = Math.random().toFixed(2);
        const cpc = (Math.random() * 5).toFixed(2);
        
        result += `### ${keyword}\n\n`;
        result += `- **Type**: ${wordCount > 2 ? 'Long-tail' : 'Short-tail'} keyword\n`;
        result += `- **Difficulty**: ${difficulty}/100 (${getDifficultyLevel(difficulty)})\n`;
        result += `- **Search Volume**: ~${volume} searches/month\n`;
        result += `- **Competition**: ${competition} (${getCompetitionLevel(parseFloat(competition))})\n`;
        result += `- **Estimated CPC**: $${cpc}\n\n`;
        
        // Recommendations
        result += `**Recommendations**:\n`;
        if (difficulty > 70) {
          result += `- Consider targeting more specific long-tail variations of this keyword\n`;
        } else if (difficulty < 30) {
          result += `- Good opportunity for quick wins, optimize existing content for this keyword\n`;
        }
        
        if (volume < 100) {
          result += `- Low search volume, may not drive significant traffic\n`;
        } else if (volume > 5000) {
          result += `- High search volume, but may be harder to rank for\n`;
        }
        
        result += `- ${getRandomAdvice()}\n\n`;
      });
      
      // Overall recommendations
      result += `## Overall Strategy Recommendations\n\n`;
      result += `1. Focus on keywords with medium difficulty (30-60) for balanced approach\n`;
      result += `2. Incorporate keywords naturally in your content, headers, and meta tags\n`;
      result += `3. Create comprehensive content that covers related topics\n`;
      result += `4. Build quality backlinks to improve domain authority\n`;
      result += `5. Regularly monitor rankings and adjust strategy accordingly\n`;
      
      return result;
    } catch (error) {
      console.error("Error analyzing keywords:", error);
      return "An error occurred while analyzing keywords. Please try again.";
    }
  };
  
  // Helper functions for the analysis
  const getDifficultyLevel = (score: number) => {
    if (score < 30) return "Easy";
    if (score < 60) return "Moderate";
    if (score < 80) return "Difficult";
    return "Very Difficult";
  };
  
  const getCompetitionLevel = (score: number) => {
    if (score < 0.3) return "Low";
    if (score < 0.7) return "Medium";
    return "High";
  };
  
  const getRandomAdvice = () => {
    const advice = [
      "Create a dedicated page focused on this keyword",
      "Include this keyword in your title tags and meta descriptions",
      "Add this keyword to your header tags (H1, H2)",
      "Create visual content (infographics, videos) around this topic",
      "Write a comprehensive guide targeting this keyword",
      "Include this keyword in image alt text where relevant",
      "Build quality backlinks to pages targeting this keyword",
      "Create FAQ content addressing questions related to this keyword",
      "Use this keyword in your URL structure"
    ];
    return advice[Math.floor(Math.random() * advice.length)];
  };

  // Define the fields for the tool interface
  const fields = [
    {
      id: "keywords",
      label: "Keywords (comma separated)",
      type: "textarea" as const,
      placeholder: "Enter keywords separated by commas (e.g., digital marketing, SEO tools, content strategy)"
    },
    {
      id: "industry",
      label: "Industry/Niche",
      type: "text" as const,
      placeholder: "E.g., Health, Technology, Education, Finance"
    },
    {
      id: "language",
      label: "Target Language",
      type: "select" as const,
      placeholder: "Select target language",
      options: [
        { value: "en", label: "English" },
        { value: "es", label: "Spanish" },
        { value: "fr", label: "French" },
        { value: "de", label: "German" },
        { value: "it", label: "Italian" },
        { value: "pt", label: "Portuguese" },
        { value: "ja", label: "Japanese" },
        { value: "zh", label: "Chinese" },
        { value: "hi", label: "Hindi" },
        { value: "ar", label: "Arabic" }
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>SEO Keyword Tool - Zyfoox</title>
        <meta 
          name="description" 
          content="Analyze and optimize your keywords for better search engine rankings and visibility. Free online SEO keyword analysis tool." 
        />
        <meta 
          name="keywords" 
          content="SEO keyword tool, keyword analysis, SEO analysis, keyword research, search engine optimization tool" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/seo-keyword-tool" />
      </Helmet>

      <ToolHero
        title="SEO Keyword Tool"
        description="Analyze and optimize your keywords for better search engine rankings and visibility."
        icon={<Search size={32} />}
      />

      <ToolInterface
        toolName="SEO Keyword Analysis"
        fields={fields}
        generateFunction={analyzeKeywords}
      />
    </>
  );
}
