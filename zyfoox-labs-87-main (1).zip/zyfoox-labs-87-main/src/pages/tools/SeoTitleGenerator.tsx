
import { useState } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import ToolInterface from "@/components/tools/ToolInterface";
import { Type } from "lucide-react";

export default function SeoTitleGenerator() {
  // Function to generate SEO titles
  const generateSeoTitles = async (formData: Record<string, string>) => {
    try {
      const { keyword, industry, contentType, brand } = formData;
      
      // These would typically come from an API call to an AI service
      // For demo purposes, we'll use templates and variations
      const templates = [
        `${keyword} - Ultimate Guide for ${industry} [${new Date().getFullYear()}]`,
        `Top 10 ${keyword} Strategies for ${industry} Professionals`,
        `How to Master ${keyword}: Expert Tips for ${industry}`,
        `The Complete ${keyword} Guide | ${brand}`,
        `${keyword}: Everything You Need to Know for ${industry} Success`,
        `Boost Your ${industry} Results with These ${keyword} Techniques`,
        `${contentType}: ${keyword} - Essential Knowledge for ${industry}`,
        `${brand}'s Guide to ${keyword} - Transform Your ${industry} Approach`,
        `${keyword} Mastery: ${contentType} for ${industry} Experts`,
        `Unlock the Secrets of ${keyword} for Your ${industry} Goals`,
        `${keyword} 101: Beginner to Expert ${contentType} for ${industry}`,
        `The ${industry} Professional's Handbook to ${keyword}`,
        `${brand} Presents: Revolutionary ${keyword} Strategies for ${industry}`,
        `${contentType}: Why ${keyword} Matters in ${industry} Today`,
        `${keyword}: ${brand}'s Proven Methods for ${industry} Success`
      ];
      
      // Generate variations
      const titles = templates.map(template => {
        // Capitalize properly
        return template.replace(/\b\w/g, c => c.toUpperCase());
      });
      
      // Format the output
      let result = `# SEO Title Suggestions for "${keyword}"\n\n`;
      result += `Industry: ${industry}\n`;
      result += `Content Type: ${contentType}\n`;
      result += `Brand: ${brand}\n\n`;
      
      result += `## Title Options\n\n`;
      
      titles.forEach((title, index) => {
        const length = title.length;
        const lengthStatus = length > 70 ? "❌ Too long" : length < 30 ? "⚠️ Too short" : "✅ Optimal length";
        
        result += `### Option ${index + 1}\n\n`;
        result += `**Title:** ${title}\n\n`;
        result += `**Character Count:** ${length} (${lengthStatus})\n\n`;
        
        // Add random effectiveness score and notes
        const score = Math.floor(Math.random() * 30) + 70; // Score between 70-100
        result += `**Effectiveness Score:** ${score}/100\n\n`;
        
        result += `**Notes:**\n`;
        if (length > 70) {
          result += `- Consider shortening to stay under 70 characters for better display in search results\n`;
        } else if (length < 30) {
          result += `- Consider adding more descriptive terms to make the title more compelling\n`;
        } else {
          result += `- Good length for search engine display\n`;
        }
        
        // Add random tips
        const tips = [
          `- Includes main keyword prominently`,
          `- Has strong action words that encourage clicks`,
          `- Creates a sense of urgency/value`,
          `- Includes the current year for freshness`,
          `- Clearly signals the content type (guide, list, tutorial)`,
          `- Incorporates brand name naturally`,
          `- Uses power words that trigger emotional response`,
          `- Contains a specific number (list format)`
        ];
        
        // Pick 2-3 random tips
        const selectedTips = [];
        for (let i = 0; i < 3; i++) {
          const randomTip = tips[Math.floor(Math.random() * tips.length)];
          if (!selectedTips.includes(randomTip)) {
            selectedTips.push(randomTip);
          }
        }
        
        result += selectedTips.join('\n');
        result += '\n\n';
      });
      
      result += `## Best Practices for SEO Titles\n\n`;
      result += `1. Keep titles under 70 characters to avoid truncation in search results\n`;
      result += `2. Place important keywords near the beginning of the title\n`;
      result += `3. Make titles compelling and click-worthy while remaining accurate\n`;
      result += `4. Use numbers and specific details where appropriate\n`;
      result += `5. Include your brand name for recognition (typically at the end)\n`;
      result += `6. Avoid keyword stuffing which can trigger spam filters\n`;
      result += `7. Consider using emotional triggers or power words\n`;
      result += `8. Ensure the title accurately represents your content to reduce bounce rates\n`;
      
      return result;
    } catch (error) {
      console.error("Error generating SEO titles:", error);
      return "An error occurred while generating SEO titles. Please try again.";
    }
  };

  // Define the fields for the tool interface
  const fields = [
    {
      id: "keyword",
      label: "Primary Keyword",
      type: "text" as const,
      placeholder: "E.g., Content Marketing, AI Tools, SEO Strategies"
    },
    {
      id: "industry",
      label: "Industry/Niche",
      type: "text" as const,
      placeholder: "E.g., Healthcare, E-commerce, Finance, Education"
    },
    {
      id: "contentType",
      label: "Content Type",
      type: "select" as const,
      placeholder: "Select content type",
      options: [
        { value: "Blog Post", label: "Blog Post" },
        { value: "Guide", label: "Guide" },
        { value: "Tutorial", label: "Tutorial" },
        { value: "List Article", label: "List Article" },
        { value: "Product Page", label: "Product Page" },
        { value: "Landing Page", label: "Landing Page" },
        { value: "Case Study", label: "Case Study" },
        { value: "Webinar", label: "Webinar" },
        { value: "Whitepaper", label: "Whitepaper" },
        { value: "Video", label: "Video" }
      ]
    },
    {
      id: "brand",
      label: "Brand/Website Name",
      type: "text" as const,
      placeholder: "Your brand or website name"
    }
  ];

  return (
    <>
      <Helmet>
        <title>SEO Title Generator - Zyfoox</title>
        <meta 
          name="description" 
          content="Generate optimized page titles that improve click-through rates and search visibility. Free online SEO title generator." 
        />
        <meta 
          name="keywords" 
          content="SEO title generator, page title generator, meta title creator, SEO title optimizer, title tag generator" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/seo-title-generator" />
      </Helmet>

      <ToolHero
        title="SEO Title Generator"
        description="Generate optimized page titles that improve click-through rates and search visibility."
        icon={<Type size={32} />}
      />

      <ToolInterface
        toolName="SEO Title Generator"
        fields={fields}
        generateFunction={generateSeoTitles}
      />
    </>
  );
}
