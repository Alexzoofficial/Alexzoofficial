
import { useState } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import { Calculator } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function CalculatorTool() {
  const [display, setDisplay] = useState("0");
  const [currentOperation, setCurrentOperation] = useState("");
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [resetOnNextInput, setResetOnNextInput] = useState(false);

  const handleNumberClick = (num: string) => {
    if (resetOnNextInput) {
      setDisplay(num);
      setResetOnNextInput(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  };

  const handleOperationClick = (operation: string) => {
    if (previousValue === null) {
      setPreviousValue(parseFloat(display));
    } else if (currentOperation) {
      const result = calculateResult();
      setPreviousValue(result);
      setDisplay(String(result));
    }
    setCurrentOperation(operation);
    setResetOnNextInput(true);
  };

  const calculateResult = () => {
    const current = parseFloat(display);
    let result = 0;

    switch (currentOperation) {
      case "+":
        result = (previousValue || 0) + current;
        break;
      case "-":
        result = (previousValue || 0) - current;
        break;
      case "×":
        result = (previousValue || 0) * current;
        break;
      case "÷":
        result = (previousValue || 0) / current;
        break;
      default:
        return current;
    }

    return Math.round(result * 1000000) / 1000000; // Handle floating point precision
  };

  const handleEquals = () => {
    if (!currentOperation || previousValue === null) return;
    
    const result = calculateResult();
    setDisplay(String(result));
    setPreviousValue(null);
    setCurrentOperation("");
    setResetOnNextInput(true);
  };

  const handleClear = () => {
    setDisplay("0");
    setCurrentOperation("");
    setPreviousValue(null);
    setResetOnNextInput(false);
  };

  const handleDecimal = () => {
    if (resetOnNextInput) {
      setDisplay("0.");
      setResetOnNextInput(false);
    } else if (!display.includes(".")) {
      setDisplay(display + ".");
    }
  };

  return (
    <>
      <Helmet>
        <title>Calculator - Free Online Calculator | Zyfoox</title>
        <meta 
          name="description" 
          content="Free online calculator for basic and advanced mathematical operations. Simple, fast, and easy to use with no ads or registration required." 
        />
        <meta 
          name="keywords" 
          content="online calculator, web calculator, math calculator, free calculator, basic calculator, simple calculator, no ads calculator" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/calculator" />
      </Helmet>

      <ToolHero
        title="Calculator"
        description="Free online calculator for basic mathematical operations. No registration required."
        icon={<Calculator size={32} />}
      />

      <div className="container mx-auto max-w-md px-4 py-8">
        <div className="glass-card rounded-xl p-6 animate-fade-in">
          <div className="mb-4">
            <Input 
              readOnly 
              value={display} 
              className="text-right text-2xl h-14 font-mono"
            />
          </div>
          
          <div className="grid grid-cols-4 gap-2">
            <Button 
              variant="outline" 
              className="text-xl h-14" 
              onClick={handleClear}
            >
              C
            </Button>
            <Button 
              variant="outline" 
              className="text-xl h-14"
              onClick={() => {
                setDisplay(display === "0" ? "0" : display.slice(0, -1) || "0");
              }}
            >
              ←
            </Button>
            <Button 
              variant="outline"
              className="text-xl h-14"
              onClick={() => {
                setDisplay(String(parseFloat(display) * -1));
              }}
            >
              ±
            </Button>
            <Button 
              variant="secondary"
              className="text-xl h-14"
              onClick={() => handleOperationClick("÷")}
            >
              ÷
            </Button>
            
            {[7, 8, 9].map((num) => (
              <Button 
                key={num} 
                variant="outline" 
                className="text-xl h-14"
                onClick={() => handleNumberClick(num.toString())}
              >
                {num}
              </Button>
            ))}
            <Button 
              variant="secondary"
              className="text-xl h-14"
              onClick={() => handleOperationClick("×")}
            >
              ×
            </Button>
            
            {[4, 5, 6].map((num) => (
              <Button 
                key={num} 
                variant="outline" 
                className="text-xl h-14"
                onClick={() => handleNumberClick(num.toString())}
              >
                {num}
              </Button>
            ))}
            <Button 
              variant="secondary"
              className="text-xl h-14"
              onClick={() => handleOperationClick("-")}
            >
              -
            </Button>
            
            {[1, 2, 3].map((num) => (
              <Button 
                key={num} 
                variant="outline" 
                className="text-xl h-14"
                onClick={() => handleNumberClick(num.toString())}
              >
                {num}
              </Button>
            ))}
            <Button 
              variant="secondary"
              className="text-xl h-14"
              onClick={() => handleOperationClick("+")}
            >
              +
            </Button>
            
            <Button 
              variant="outline" 
              className="text-xl h-14"
              onClick={() => handleNumberClick("0")}
            >
              0
            </Button>
            <Button 
              variant="outline" 
              className="text-xl h-14"
              onClick={handleDecimal}
            >
              .
            </Button>
            <Button 
              variant="default" 
              className="text-xl h-14 col-span-2"
              onClick={handleEquals}
            >
              =
            </Button>
          </div>
        </div>
        
        <div className="glass-card rounded-xl p-6 mt-8 animate-fade-in">
          <h2 className="text-xl font-semibold mb-4">About Our Calculator</h2>
          <p className="text-muted-foreground mb-6">
            Our free online calculator provides a simple and convenient way to perform basic mathematical operations. Whether you need to calculate finances, homework problems, or everyday math, our calculator is here to help.
          </p>
          
          <h3 className="text-lg font-medium mb-2">Features:</h3>
          <ul className="list-disc list-inside text-muted-foreground mb-4 space-y-1">
            <li>Basic operations: addition, subtraction, multiplication, division</li>
            <li>Clean, responsive interface that works on any device</li>
            <li>No ads or distractions</li>
            <li>No registration or download required</li>
            <li>Fast and reliable calculations</li>
          </ul>
          
          <p className="text-muted-foreground text-sm">
            This calculator is designed for basic arithmetic operations. For more advanced scientific calculations, check out our other math tools available on Zyfoox.
          </p>
        </div>
      </div>
    </>
  );
}
