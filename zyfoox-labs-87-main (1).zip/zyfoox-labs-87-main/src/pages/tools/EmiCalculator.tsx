
import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import { DollarSign } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

export default function EmiCalculator() {
  const [loanAmount, setLoanAmount] = useState(100000);
  const [interestRate, setInterestRate] = useState(10);
  const [loanTenureYears, setLoanTenureYears] = useState(5);
  const [emi, setEmi] = useState(0);
  const [totalInterest, setTotalInterest] = useState(0);
  const [totalPayment, setTotalPayment] = useState(0);

  const calculateEMI = () => {
    // Convert interest rate from percentage to decimal and from annual to monthly
    const monthlyInterestRate = interestRate / 1200;
    
    // Convert loan tenure from years to months
    const loanTenureMonths = loanTenureYears * 12;
    
    // Calculate EMI using the formula: EMI = P * r * (1+r)^n / ((1+r)^n - 1)
    const emiValue = loanAmount * monthlyInterestRate * 
      Math.pow(1 + monthlyInterestRate, loanTenureMonths) / 
      (Math.pow(1 + monthlyInterestRate, loanTenureMonths) - 1);
    
    const totalPaymentValue = emiValue * loanTenureMonths;
    const totalInterestValue = totalPaymentValue - loanAmount;
    
    setEmi(Math.round(emiValue));
    setTotalInterest(Math.round(totalInterestValue));
    setTotalPayment(Math.round(totalPaymentValue));
  };

  useEffect(() => {
    calculateEMI();
  }, [loanAmount, interestRate, loanTenureYears]);

  return (
    <>
      <Helmet>
        <title>EMI Calculator - Zyfoox</title>
        <meta 
          name="description" 
          content="Calculate loan EMIs, total interest payable, and full amortization schedule for any loan type. Free online EMI calculator." 
        />
        <meta 
          name="keywords" 
          content="EMI calculator, loan calculator, monthly payment calculator, loan EMI, mortgage calculator" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/emi-calculator" />
      </Helmet>

      <ToolHero
        title="EMI Calculator"
        description="Calculate loan EMIs, total interest payable, and full payment schedule for any loan type."
        icon={<DollarSign size={32} />}
      />

      <div className="container mx-auto max-w-4xl px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass-card rounded-xl p-6 animate-fade-in">
            <h2 className="text-xl font-semibold mb-4">Loan Details</h2>
            
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <Label htmlFor="loan-amount">Loan Amount</Label>
                  <span className="text-sm font-medium">${loanAmount.toLocaleString()}</span>
                </div>
                <Slider
                  id="loan-amount"
                  value={[loanAmount]}
                  min={1000}
                  max={1000000}
                  step={1000}
                  onValueChange={(value) => setLoanAmount(value[0])}
                  className="mb-2"
                />
                <Input
                  type="number"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="mt-2"
                />
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <Label htmlFor="interest-rate">Interest Rate (% per year)</Label>
                  <span className="text-sm font-medium">{interestRate}%</span>
                </div>
                <Slider
                  id="interest-rate"
                  value={[interestRate]}
                  min={1}
                  max={30}
                  step={0.1}
                  onValueChange={(value) => setInterestRate(value[0])}
                  className="mb-2"
                />
                <Input
                  type="number"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="mt-2"
                  step="0.1"
                />
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <Label htmlFor="loan-tenure">Loan Tenure (years)</Label>
                  <span className="text-sm font-medium">{loanTenureYears} years</span>
                </div>
                <Slider
                  id="loan-tenure"
                  value={[loanTenureYears]}
                  min={1}
                  max={30}
                  step={1}
                  onValueChange={(value) => setLoanTenureYears(value[0])}
                  className="mb-2"
                />
                <Input
                  type="number"
                  value={loanTenureYears}
                  onChange={(e) => setLoanTenureYears(Number(e.target.value))}
                  className="mt-2"
                />
              </div>
              
              <Button onClick={calculateEMI} className="w-full">Recalculate</Button>
            </div>
          </div>
          
          <div className="glass-card rounded-xl p-6 animate-fade-in animate-delay-100">
            <h2 className="text-xl font-semibold mb-4">Loan Summary</h2>
            
            <div className="space-y-6">
              <div className="bg-primary/10 rounded-lg p-4 text-center">
                <h3 className="text-sm font-medium text-muted-foreground mb-1">Monthly EMI</h3>
                <p className="text-3xl font-bold">${emi.toLocaleString()}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-secondary/20 rounded-lg p-4 text-center">
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Principal</h3>
                  <p className="text-xl font-semibold">${loanAmount.toLocaleString()}</p>
                </div>
                
                <div className="bg-secondary/20 rounded-lg p-4 text-center">
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Interest</h3>
                  <p className="text-xl font-semibold">${totalInterest.toLocaleString()}</p>
                </div>
              </div>
              
              <div className="bg-primary/5 rounded-lg p-4">
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Total Payment</span>
                  <span className="font-semibold">${totalPayment.toLocaleString()}</span>
                </div>
                
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Loan Tenure</span>
                  <span className="font-semibold">{loanTenureYears} years ({loanTenureYears * 12} months)</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Interest Rate</span>
                  <span className="font-semibold">{interestRate}% per year</span>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-primary/20 to-secondary/20 h-4 rounded-full overflow-hidden">
                <div 
                  className="bg-primary h-full" 
                  style={{ width: `${(loanAmount / totalPayment) * 100}%` }}
                ></div>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Principal: {Math.round((loanAmount / totalPayment) * 100)}%</span>
                <span className="text-muted-foreground">Interest: {Math.round((totalInterest / totalPayment) * 100)}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
