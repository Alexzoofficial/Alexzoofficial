
import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import { ShoppingCart } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function EcommerceCalculator() {
  // Revenue calculator state
  const [productPrice, setProductPrice] = useState(50);
  const [quantity, setQuantity] = useState(100);
  const [shippingFee, setShippingFee] = useState(5);
  const [taxRate, setTaxRate] = useState(7);
  
  // Profit calculator state
  const [productCost, setProductCost] = useState(25);
  const [packagingCost, setPackagingCost] = useState(2);
  const [marketingCost, setMarketingCost] = useState(500);
  const [platformFee, setPlatformFee] = useState(5);
  
  // Shipping calculator state
  const [weight, setWeight] = useState(1);
  const [baseShippingRate, setBaseShippingRate] = useState(3.99);
  const [additionalWeight, setAdditionalWeight] = useState(0.5);
  const [additionalRate, setAdditionalRate] = useState(1.50);
  
  // Results
  const [grossRevenue, setGrossRevenue] = useState(0);
  const [netRevenue, setNetRevenue] = useState(0);
  const [totalCost, setTotalCost] = useState(0);
  const [profitMargin, setProfitMargin] = useState(0);
  const [roi, setRoi] = useState(0);
  const [shippingCost, setShippingCost] = useState(0);

  useEffect(() => {
    // Calculate revenue
    const subtotal = productPrice * quantity;
    const shipping = shippingFee * quantity;
    const tax = (subtotal * taxRate) / 100;
    const gross = subtotal + shipping + tax;
    setGrossRevenue(gross);
    
    // Calculate costs
    const prodCost = productCost * quantity;
    const packageCost = packagingCost * quantity;
    const platformCost = (subtotal * platformFee) / 100;
    const total = prodCost + packageCost + marketingCost + platformCost;
    setTotalCost(total);
    
    // Calculate net revenue and profit margin
    const net = gross - total;
    setNetRevenue(net);
    setProfitMargin(gross > 0 ? (net / gross) * 100 : 0);
    setRoi(total > 0 ? (net / total) * 100 : 0);
    
    // Calculate shipping cost
    let ship = baseShippingRate;
    if (weight > 1) {
      const extra = Math.ceil((weight - 1) / additionalWeight);
      ship += extra * additionalRate;
    }
    setShippingCost(ship);
  }, [
    productPrice, quantity, shippingFee, taxRate, 
    productCost, packagingCost, marketingCost, platformFee,
    weight, baseShippingRate, additionalWeight, additionalRate
  ]);

  return (
    <>
      <Helmet>
        <title>E-Commerce Calculator - Zyfoox</title>
        <meta 
          name="description" 
          content="Calculate shipping costs, profit margins, and other e-commerce metrics for your online store. Free online e-commerce calculator." 
        />
        <meta 
          name="keywords" 
          content="e-commerce calculator, online store calculator, shipping calculator, profit calculator for e-commerce, e-commerce profit margin" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/ecommerce-calculator" />
      </Helmet>

      <ToolHero
        title="E-Commerce Calculator"
        description="Calculate shipping costs, profit margins, and other e-commerce metrics for your online store."
        icon={<ShoppingCart size={32} />}
      />

      <div className="container mx-auto max-w-5xl px-4 py-8">
        <Tabs defaultValue="revenue" className="glass-card rounded-xl p-6 animate-fade-in">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="profit">Profit</TabsTrigger>
            <TabsTrigger value="shipping">Shipping</TabsTrigger>
          </TabsList>
          
          <TabsContent value="revenue" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="product-price">Product Price ($)</Label>
                  <Input
                    id="product-price"
                    type="number"
                    value={productPrice}
                    onChange={(e) => setProductPrice(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="quantity">Quantity (units)</Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
                    min="0"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="shipping-fee">Shipping Fee per Item ($)</Label>
                  <Input
                    id="shipping-fee"
                    type="number"
                    value={shippingFee}
                    onChange={(e) => setShippingFee(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="tax-rate">Tax Rate (%)</Label>
                  <Input
                    id="tax-rate"
                    type="number"
                    value={taxRate}
                    onChange={(e) => setTaxRate(parseFloat(e.target.value) || 0)}
                    min="0"
                    max="100"
                    step="0.1"
                    className="mt-1"
                  />
                </div>
              </div>
              
              <div className="space-y-4 bg-secondary/10 p-4 rounded-lg">
                <h3 className="text-lg font-medium">Revenue Summary</h3>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Product Subtotal</span>
                  <span className="font-medium">${(productPrice * quantity).toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping Total</span>
                  <span className="font-medium">${(shippingFee * quantity).toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax</span>
                  <span className="font-medium">${((productPrice * quantity * taxRate) / 100).toFixed(2)}</span>
                </div>
                
                <div className="border-t pt-2 mt-2">
                  <div className="flex justify-between text-lg">
                    <span className="font-medium">Gross Revenue</span>
                    <span className="font-bold">${grossRevenue.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="profit" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="product-cost">Product Cost per Unit ($)</Label>
                  <Input
                    id="product-cost"
                    type="number"
                    value={productCost}
                    onChange={(e) => setProductCost(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="packaging-cost">Packaging Cost per Unit ($)</Label>
                  <Input
                    id="packaging-cost"
                    type="number"
                    value={packagingCost}
                    onChange={(e) => setPackagingCost(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="marketing-cost">Marketing Cost (Total $)</Label>
                  <Input
                    id="marketing-cost"
                    type="number"
                    value={marketingCost}
                    onChange={(e) => setMarketingCost(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="platform-fee">Platform Fee (%)</Label>
                  <Input
                    id="platform-fee"
                    type="number"
                    value={platformFee}
                    onChange={(e) => setPlatformFee(parseFloat(e.target.value) || 0)}
                    min="0"
                    max="100"
                    step="0.1"
                    className="mt-1"
                  />
                </div>
              </div>
              
              <div className="space-y-4 bg-secondary/10 p-4 rounded-lg">
                <h3 className="text-lg font-medium">Profit Analysis</h3>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Product Cost</span>
                  <span className="font-medium">${(productCost * quantity).toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Packaging Cost</span>
                  <span className="font-medium">${(packagingCost * quantity).toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Marketing Cost</span>
                  <span className="font-medium">${marketingCost.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Platform Fees</span>
                  <span className="font-medium">${((productPrice * quantity * platformFee) / 100).toFixed(2)}</span>
                </div>
                
                <div className="border-t pt-2 mt-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Costs</span>
                    <span className="font-medium">${totalCost.toFixed(2)}</span>
                  </div>
                  
                  <div className="flex justify-between mt-2">
                    <span className="text-muted-foreground">Net Revenue</span>
                    <span className={`font-bold ${netRevenue < 0 ? 'text-red-500' : 'text-green-500'}`}>
                      ${netRevenue.toFixed(2)}
                    </span>
                  </div>
                  
                  <div className="flex justify-between mt-2">
                    <span className="text-muted-foreground">Profit Margin</span>
                    <span className={`font-medium ${profitMargin < 0 ? 'text-red-500' : 'text-green-500'}`}>
                      {profitMargin.toFixed(2)}%
                    </span>
                  </div>
                  
                  <div className="flex justify-between mt-2">
                    <span className="text-muted-foreground">ROI</span>
                    <span className={`font-medium ${roi < 0 ? 'text-red-500' : 'text-green-500'}`}>
                      {roi.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="shipping" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="weight">Package Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    value={weight}
                    onChange={(e) => setWeight(parseFloat(e.target.value) || 0)}
                    min="0.1"
                    step="0.1"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="base-rate">Base Shipping Rate ($)</Label>
                  <Input
                    id="base-rate"
                    type="number"
                    value={baseShippingRate}
                    onChange={(e) => setBaseShippingRate(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="additional-weight">Additional Weight Increment (kg)</Label>
                  <Input
                    id="additional-weight"
                    type="number"
                    value={additionalWeight}
                    onChange={(e) => setAdditionalWeight(parseFloat(e.target.value) || 0.1)}
                    min="0.1"
                    step="0.1"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="additional-rate">Rate per Additional Weight ($)</Label>
                  <Input
                    id="additional-rate"
                    type="number"
                    value={additionalRate}
                    onChange={(e) => setAdditionalRate(parseFloat(e.target.value) || 0)}
                    min="0"
                    step="0.01"
                    className="mt-1"
                  />
                </div>
              </div>
              
              <div className="space-y-4 bg-secondary/10 p-4 rounded-lg">
                <h3 className="text-lg font-medium">Shipping Cost Calculation</h3>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Base Shipping Rate</span>
                  <span className="font-medium">${baseShippingRate.toFixed(2)}</span>
                </div>
                
                {weight > 1 && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">
                        Additional Weight Charges
                        <div className="text-xs">
                          {Math.ceil((weight - 1) / additionalWeight)} x ${additionalRate.toFixed(2)}
                        </div>
                      </span>
                      <span className="font-medium">
                        ${(Math.ceil((weight - 1) / additionalWeight) * additionalRate).toFixed(2)}
                      </span>
                    </div>
                  </>
                )}
                
                <div className="border-t pt-2 mt-2">
                  <div className="flex justify-between text-lg">
                    <span className="font-medium">Total Shipping Cost</span>
                    <span className="font-bold">${shippingCost.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
