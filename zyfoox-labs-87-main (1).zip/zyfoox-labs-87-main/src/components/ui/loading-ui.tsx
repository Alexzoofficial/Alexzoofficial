
import { LoadingSpinner } from "./loading-spinner";

interface LoadingUIProps {
  message?: string;
}

export function LoadingUI({ message = "Loading..." }: LoadingUIProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[200px] p-8 animate-fade-in">
      <div className="glass-card rounded-xl p-6 flex flex-col items-center">
        <LoadingSpinner size="lg" className="mb-4" />
        <div className="text-gradient font-display font-semibold">{message}</div>
      </div>
    </div>
  );
}
